#ifndef USER_H
#define USER_H

#include <string>
#include "DesignByContract.h"

class User {
private:
    std::string name;
    User* _initCheck; // Gecorrigeerd naar User*

public:
    // Constructor
    User(std::string n) : name(n) {
        // Markeer als geïnitialiseerd
        _initCheck = this;

        // Contracten
        REQUIRE(!n.empty(), "Gebruikersnaam mag niet leeg zijn");

        ENSURE(properlyInitialized(), "User niet correct geinitialiseerd");
        ENSURE(getName() == n, "Naam niet correct opgeslagen");
    }

    // De veiligheidscheck
    bool properlyInitialized() const {
        return _initCheck == this;
    }

    std::string getName() const {
        // Check of het object wel 'leeft'
        REQUIRE(properlyInitialized(), "User niet geinitialiseerd");
        return name;
    }
};

#endif