#ifndef MEETING_H
#define MEETING_H

#include <string>
#include <vector>
#include "DesignByContract.h"

class Meeting {
private:
    std::string identifier;
    std::string roomID;
    std::string date;
    std::vector<std::string> participants;
    Meeting* _initCheck; // NIEUW: De pointer voor de veiligheidscheck

public:
    // De constructor
    Meeting(std::string id, std::string rID, std::string d)
        : identifier(id), roomID(rID), date(d) {

        _initCheck = this; // NIEUW: Markeer als geïnitialiseerd

        REQUIRE(!id.empty(), "Meeting identifier mag niet leeg zijn");
        ENSURE(properlyInitialized(), "Meeting is niet correct aangemaakt"); // NIEUW
    }

    // NIEUW: De check-functie zelf
    bool properlyInitialized() const {
        return _initCheck == this;
    }

    std::string getIdentifier() const {
        REQUIRE(properlyInitialized(), "Meeting niet geinitialiseerd"); // NIEUW
        return identifier;
    }

    std::string getRoomID() const {
        REQUIRE(properlyInitialized(), "Meeting niet geinitialiseerd"); // NIEUW
        return roomID;
    }

    std::string getDate() const {
        REQUIRE(properlyInitialized(), "Meeting niet geinitialiseerd"); // NIEUW
        return date;
    }

    void addParticipant(std::string name) {
        REQUIRE(properlyInitialized(), "Meeting niet geinitialiseerd"); // NIEUW
        participants.push_back(name);
    }

    std::vector<std::string> getParticipants() const {
        REQUIRE(properlyInitialized(), "Meeting niet geinitialiseerd"); // NIEUW
        return participants;
    }
};

#endif