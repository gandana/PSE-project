#ifndef ROOM_H
#define ROOM_H

#include <string>
#include "DesignByContract.h"

class Room {
private:
    std::string identifier;
    int capacity;
    Room* _initCheck; // Gecorrigeerd: moet een Room pointer zijn

public:
    // Constructor
    Room(std::string id, int cap) : identifier(id), capacity(cap) {
        // Markeer als geïnitialiseerd
        _initCheck = this;

        // Contracten
        REQUIRE(!id.empty(), "Kamer identifier mag niet leeg zijn");
        REQUIRE(cap > 0, "Capaciteit moet groter zijn dan 0");

        ENSURE(properlyInitialized(), "Room is niet correct aangemaakt");
    }

    // De veiligheidscheck
    bool properlyInitialized() const {
        return _initCheck == this;
    }

    std::string getIdentifier() const {
        REQUIRE(properlyInitialized(), "Room niet geinitialiseerd");
        return identifier;
    }

    int getCapacity() const {
        REQUIRE(properlyInitialized(), "Room niet geinitialiseerd");
        return capacity;
    }
};

#endif