#ifndef MEETINGPLANNER_H
#define MEETINGPLANNER_H

#include <vector>
#include <iostream>
#include <ostream>
#include "Room.h"
#include "User.h"
#include "Meeting.h"
#include "DesignByContract.h"

class MeetingPlanner {
private:
    std::vector<Room*> rooms;
    std::vector<User*> users;
    std::vector<Meeting*> meetings;
    MeetingPlanner* _initCheck; // De pointer voor de veiligheidscheck

public:
    // Constructor
    MeetingPlanner() {
        _initCheck = this;
        ENSURE(properlyInitialized(), "MeetingPlanner niet correct geïnitialiseerd");
    }

    // Destructor: HEEL BELANGRIJK voor PSE (geheugen opruimen)
    ~MeetingPlanner() {
        REQUIRE(properlyInitialized(), "MeetingPlanner niet geinitialiseerd bij aanroep destructor");
        for (Room* r : rooms) delete r;
        for (User* u : users) delete u;
        for (Meeting* m : meetings) delete m;
    }

    bool properlyInitialized() const {
        return _initCheck == this;
    }

    void addRoom(Room* r) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        rooms.push_back(r);
    }

    void addUser(User* u) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        users.push_back(u);
    }

    void addMeeting(Meeting* m) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        meetings.push_back(m);
    }

    void addParticipationToMeeting(std::string mID, std::string uName) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        for (Meeting* m : meetings) {
            if (m->getIdentifier() == mID) {
                m->addParticipant(uName);
                return;
            }
        }
    }

    // Hulpmiddel voor validatie: Bestaat een kamer wel?
    bool roomExists(std::string id) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        for (Room* r : rooms) {
            if (r->getIdentifier() == id) return true;
        }
        return false;
    }

    void printReport(std::ostream& os) {
        REQUIRE(properlyInitialized(), "Planner niet geinitialiseerd");
        os << "=== MEETING PLANNER REPORT ===" << std::endl;

        os << "Rooms:" << std::endl;
        for (Room* r : rooms) {
            os << " - " << r->getIdentifier() << " (capacity " << r->getCapacity() << ")" << std::endl;
        }

        os << "Users:" << std::endl;
        for (User* u : users) {
            os << " - " << u->getName() << std::endl;
        }

        os << "Meetings:" << std::endl;
        for (Meeting* m : meetings) {
            os << " - " << m->getIdentifier() << " in " << m->getRoomID() << " on " << m->getDate() << std::endl;

            std::vector<std::string> parts = m->getParticipants();
            if (!parts.empty()) {
                os << "   Participants: ";
                for (size_t i = 0; i < parts.size(); ++i) {
                    os << parts[i] << (i == parts.size() - 1 ? "" : ", ");
                }
                os << std::endl;
            }
        }
    }
};

#endif