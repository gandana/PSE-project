#include <iostream>
#include <fstream> // Nieuw: voor het bestand
#include "tinyxml.h"
#include "Room.h"
#include "User.h"
#include "Meeting.h"
#include "MeetingPlanner.h"

int main() {
    // 1. XML Laden
    TiXmlDocument doc;
    if (!doc.LoadFile("test.xml")) {
        std::cerr << "Fout bij laden: " << doc.ErrorDesc() << std::endl;
        return 1;
    }

    TiXmlElement* root = doc.FirstChildElement("SYSTEM");
    if (!root) return 1;

    MeetingPlanner planner;

    // 2. Kamers inlezen
    for (TiXmlElement* elem = root->FirstChildElement("ROOM"); elem; elem = elem->NextSiblingElement("ROOM")) {
        std::string id = elem->Attribute("IDENTIFIER") ? elem->Attribute("IDENTIFIER") : "";
        int cap = 0;
        elem->QueryIntAttribute("CAPACITY", &cap);
        if(!id.empty() && cap > 0) planner.addRoom(new Room(id, cap));
    }

    // 3. Gebruikers inlezen
    for (TiXmlElement* elem = root->FirstChildElement("USER"); elem; elem = elem->NextSiblingElement("USER")) {
        std::string name = elem->Attribute("NAME") ? elem->Attribute("NAME") : "";
        if(!name.empty()) planner.addUser(new User(name));
    }

    // 4. Meetings inlezen
    for (TiXmlElement* elem = root->FirstChildElement("MEETING"); elem; elem = elem->NextSiblingElement("MEETING")) {
        std::string id = elem->Attribute("IDENTIFIER") ? elem->Attribute("IDENTIFIER") : "";
        std::string room = elem->Attribute("ROOM") ? elem->Attribute("ROOM") : "";
        std::string date = elem->Attribute("DATE") ? elem->Attribute("DATE") : "";

        // Check of de kamer wel bestaat!
        if (planner.roomExists(room)) {
            planner.addMeeting(new Meeting(id, room, date));
        } else {
            std::cerr << "Fout: Kamer " << room << " bestaat niet. Meeting " << id << " genegeerd." << std::endl;
        }
    }
    // 5. Participaties inlezen
    for (TiXmlElement* elem = root->FirstChildElement("PARTICIPATION"); elem; elem = elem->NextSiblingElement("PARTICIPATION")) {
        std::string userName = elem->Attribute("USER") ? elem->Attribute("USER") : "";
        std::string meetingID = elem->Attribute("MEETING") ? elem->Attribute("MEETING") : "";

        if (!userName.empty() && !meetingID.empty()) {
            // We moeten de juiste meeting zoeken in de planner om de user toe te voegen
            planner.addParticipationToMeeting(meetingID, userName);
        }
    }

    // --- OUTPUT SECTIE ---

    // Print naar console (voor jezelf)
    planner.printReport(std::cout);

    // Print naar bestand (voor de indiening)
    std::ofstream outputFile("output.txt");
    if (outputFile.is_open()) {
        planner.printReport(outputFile);
        outputFile.close();
        std::cout << "\nVerslag succesvol opgeslagen in output.txt" << std::endl;
    } else {
        std::cerr << "Fout: kon output.txt niet aanmaken." << std::endl;
    }

    return 0;
}